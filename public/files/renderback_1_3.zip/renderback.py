bl_info = {
    "name": "Render Back",
    "author": "Elton Matiwane",
    "version": (1, 3),
    "blender": (2, 80, 0),
    "location": "Output",
    "description": "Faster renders using command instead of direct renders from Blender",
    "category": "Output",
    "doc_url": "https://tinyurl.com/renderback1",
    "support_url": "https://www.paypal.com/paypalme/skelloton?country.x=ZA&locale.x=en_US",
}

import bpy
import os
import subprocess
import sys


class RenderBackPanel(bpy.types.Panel):
    bl_idname = "RENDERBACK_PT_Panel"
    bl_label = "RenderBack"
    bl_category = "Output"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "output"

    def draw(self, context):
        layout = self.layout

        scene = context.scene
        render_back_props = scene.renderback_props

        layout.prop(render_back_props, "B_loc")
        layout.prop(render_back_props, "project_file")
        layout.prop(render_back_props, "render_type")
        layout.operator("renderback.render")
        
        layout.operator("wm.url_open", text="Support").url = bl_info["support_url"]



class RenderBackProperties(bpy.types.PropertyGroup):
    B_loc: bpy.props.StringProperty(
        name="Blender Location",
        description="Location of Blender program",
        default=sys.argv[0],  # Set Blender executable as default
    )

    def update_project_file(self, context):
        if bpy.data.filepath:
            self.project_file = bpy.data.filepath

    project_file: bpy.props.StringProperty(
        name="Project File",
        description="Project file to render",
        default="",
        subtype='FILE_PATH',
        update=update_project_file,
    )

    turn_off: bpy.props.BoolProperty(
        name="Turn off Computer",
        description="Turn off the computer after rendering",
        default=False,
    )

    render_type: bpy.props.EnumProperty(
        name="Render Type",
        description="Select render type",
        items=[
            ('ANIMATION', "Animation", "Render animation"),
            ('IMAGE', "Image", "Render a single image"),
        ],
        default='ANIMATION',
    )


class RenderBackOperator(bpy.types.Operator):
    bl_idname = "renderback.render"
    bl_label = "RenderBack"
    bl_description = "RenderBack Add-on"

    def get_start_end_frame(self):
        scene = bpy.context.scene
        return scene.frame_start, scene.frame_end

    def execute(self, context):
        start_frame, end_frame = self.get_start_end_frame()

        render_back_props = context.scene.renderback_props

        if render_back_props.project_file == "":
            # Use the active project file if no file is specified
            render_back_props.project_file = bpy.data.filepath

        if render_back_props.render_type == 'ANIMATION':
            render_command = [
                render_back_props.B_loc,
                "-b", render_back_props.project_file,
                "-s", str(start_frame),
                "-e", str(end_frame),
                "-a"
            ]
        else:
            current_frame = bpy.context.scene.frame_current
            render_command = [
                render_back_props.B_loc,
                "-b", render_back_props.project_file,
                "-f", str(current_frame),
            ]

        # Run the render command in the background based on the operating system
        if sys.platform.startswith('win'):  # Windows
            subprocess.Popen(render_command, creationflags=subprocess.CREATE_NEW_CONSOLE)
        elif sys.platform.startswith('darwin'):  # macOS
            subprocess.Popen(['open', '-W', '--hide', '--background'] + render_command)
        else:  # Linux or other Unix-based systems
            subprocess.Popen(render_command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        return {'FINISHED'}


classes = (RenderBackPanel, RenderBackProperties, RenderBackOperator)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.renderback_props = bpy.props.PointerProperty(type=RenderBackProperties)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.renderback_props


if __name__ == "__main__":
    register()
